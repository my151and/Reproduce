﻿using SoftFluent.Windows;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;

namespace ValidationSample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // register my custom activator
            ServiceProvider.Current.SetService(typeof(IActivator), new CustomActivator());
        }

        // my custom activator
        private class CustomActivator : BaseActivator
        {
            public override object CreateInstance(Type type, params object[] args)
            {
                // when asked for PropertyGridProperty, use our own
                if (type == typeof(PropertyGridProperty))
                    return new CustomProperty((PropertyGridDataProvider)args[0]);

                return base.CreateInstance(type, args);
            }
        }

        // my custom PropertyGrid property
        private class CustomProperty : PropertyGridProperty
        {
            public CustomProperty(PropertyGridDataProvider dataProvider) : base(dataProvider)
            {
            }

            protected override void Validate(IList<string> errors, string memberName)
            {
                // check the connected object supports IDataErrorInfo 
                if (DataProvider.Data is IDataErrorInfo ao)
                {
                    // use the name of this instance as the member name
                    var error = ao[Name];
                    if (error != null)
                    {
                        errors.Add(error);
                    }
                }
                base.Validate(errors, memberName);
            }
        }
    }
}
