﻿namespace ValidationSample
{
    using SoftFluent.Windows;
    public class SomeDataWithNotifications : NotifyDataErrorInfoBase
    {
        private int val1;
        //[PropertyGridOptions(EditorDataTemplateResourceKey = "TEEditorV")]
        public int Val1
        {
            get { return val1; }
            set
            {
                SetProperty(ref val1, value);
                if (val1 < 0)
                {
                    SetError("This is Error Notification");
                }
                else
                    ClearErrors();
               
            }
        }
    }
}
